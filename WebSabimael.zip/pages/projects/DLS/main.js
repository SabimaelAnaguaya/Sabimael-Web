/* const btnMenubar = document.querySelector('#btn-menubar');
const lines = document.querySelectorAll('.line');
const menuBar = document.querySelector('.menubar');

function openMenubar(){
    lines[0].classList.toggle('line1');
    lines[1].classList.toggle('line2');
    lines[2].classList.toggle('line3');

    menuBar.classList.toggle('show');
}

btnMenubar.addEventListener('click', openMenubar); */

/* let mainUbication = window.pageXOffset;
let navbar = document.querySelector('nav-bar').shadowRoot.querySelector('.main-header');
console.log(navbar)

window.onscroll = function(){
    let actualScroll = window.pageYOffset;
    if(mainUbication >= actualScroll){
        navbar.shadowRoot.classList.remove('hide-navbar')
    }else{
        navbar.shadowRoot.classList.add('hide-navbar');
    }

    mainUbication = actualScroll;
} */